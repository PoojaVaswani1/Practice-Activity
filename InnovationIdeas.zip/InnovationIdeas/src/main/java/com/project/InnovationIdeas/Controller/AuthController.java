package com.project.InnovationIdeas.Controller;

import com.project.InnovationIdeas.Requests.RegisterRequest;
import com.project.InnovationIdeas.Responses.RegisterResponse;
import com.project.InnovationIdeas.Service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/auth")
public class AuthController {
    @Autowired
    private UserService userService;
   @PostMapping("/register")
    public ResponseEntity<RegisterResponse> register(@RequestBody RegisterRequest registerRequest){
        return new ResponseEntity<>(userService.register(registerRequest) , HttpStatus.CREATED) ;
    }
    @PostMapping("/verify")
    public ResponseEntity<?> verifyUser(@RequestParam String email, @RequestParam String otp){
       try {
           userService.verify(email, otp);
           return new ResponseEntity<>("User is verified successfully", HttpStatus.BAD_REQUEST);
       }catch (RuntimeException e){
        return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
       }
    }
}
