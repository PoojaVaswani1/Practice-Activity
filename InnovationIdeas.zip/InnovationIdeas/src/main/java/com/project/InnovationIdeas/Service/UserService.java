package com.project.InnovationIdeas.Service;

import com.project.InnovationIdeas.Requests.RegisterRequest;
import com.project.InnovationIdeas.Responses.RegisterResponse;

public interface UserService {

 RegisterResponse register(RegisterRequest registerRequest);
 void verify(String email,String otp);
}
