package com.project.InnovationIdeas.Service;

import com.project.InnovationIdeas.Repo.UserRepo;
import com.project.InnovationIdeas.Requests.RegisterRequest;
import com.project.InnovationIdeas.Responses.RegisterResponse;
import com.project.InnovationIdeas.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class UserServiceimpl implements UserService{
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private EmailService emailService;

    @Override
    public RegisterResponse register(RegisterRequest registerRequest) {
        User existingUser = userRepo.findByEmailId(registerRequest.getEmailId());
        // && existingUser.isVerified()
        if(existingUser != null && existingUser.isVerified()){
            throw new RuntimeException("User already exists!!!");
        }
        // user creation...
        User user = User.builder()
                .firstName(registerRequest.getFirstName())
                .lastName(registerRequest.getLastName())
                .phoneNumber(registerRequest.getPhoneNumber())
                .emailId(registerRequest.getEmailId())
                .password(registerRequest.getPassword())
                .confirmPassword(registerRequest.getConfirmPassword())
                .address(registerRequest.getAddress())
                .build();

        String otp = generateOTP();
        user.setOtp(otp);
        // save user in db
        userRepo.save(user);
        sendVerificationEmail(user.getEmailId(),otp);

        RegisterResponse response = RegisterResponse.builder()
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .phoneNumber(user.getPhoneNumber())
                .emailId(user.getEmailId())
                .address(user.getAddress())
                .build();

        return response;
    }

    @Override
    public void verify(String email, String otp) {
        User user = userRepo.findByEmailId(email);
        if(user == null){
            throw new RuntimeException("User not found");
        } else if (user.isVerified()) {
            throw new RuntimeException("User is verified");
        }else if (otp.equals(user.getOtp())) {
            user.setVerified(true);
            userRepo.save(user);
        }else {
            throw new RuntimeException("Internal Server error");
        }
    }

    private String generateOTP(){
        Random random = new Random();
        int otpValue = 100000 + random.nextInt(900000);
        return String.valueOf(otpValue);
    }

    private void sendVerificationEmail(String email,String otp){
        String subject = "Email Verification";
        String body = "your OTP is :" +otp;
        emailService.sendEmail(email,subject,otp);
    }

}

