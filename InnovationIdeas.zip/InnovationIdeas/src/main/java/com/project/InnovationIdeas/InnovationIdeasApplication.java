package com.project.InnovationIdeas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InnovationIdeasApplication {

	public static void main(String[] args) {
		SpringApplication.run(InnovationIdeasApplication.class, args);
	}

}
