package com.project.InnovationIdeas.Requests;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RegisterRequest {

    private String firstName;
    private String lastName;
    private int phoneNumber;
    private String emailId;
    private String password;
    private String confirmPassword;
    private String address;

}
