package com.project.InnovationIdeas.model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "USERS")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    private int phoneNumber;
    private String emailId;
    private String password;
    private String confirmPassword;
    private String address;
    private String otp;
    private boolean verified;





}
//first name, last name, phone number, email id, password, confirm password, isAdminUser, address)