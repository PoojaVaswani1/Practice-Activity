package com.project.InnovationIdeas.Responses;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RegisterResponse {

    private String firstName;
    private String lastName;
    private int phoneNumber;
    private String emailId;
    private String address;

}
