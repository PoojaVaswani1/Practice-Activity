package com.project.InnovationIdeas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnovationIdeasApplicationTests {

	@Test
	void contextLoads() {
	}

}
